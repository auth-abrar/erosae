'use client';

import React from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { ShoppingBag, Star, Eye } from 'lucide-react';

export interface ProductCardProps {
  product: {
    id: string;
    slug: string;
    titleEn: string;
    titleBn: string;
    basePriceUSD: number;
    comparePriceUSD?: number | null;
    sku: string;
    brand?: string | null;
    ratingAverage: number;
    ratingCount: number;
    images?: { url: string; isPrimary: boolean }[];
    category?: { nameEn: string; nameBn: string; slug: string };
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const { locale, formatPrice, addToCart, t } = useStore();
  const isBengali = locale === 'bn';

  const primaryImage =
    product.images?.find((img) => img.isPrimary)?.url ||
    product.images?.[0]?.url ||
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80';

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({
      id: `${product.id}-base`,
      productId: product.id,
      titleEn: product.titleEn,
      titleBn: product.titleBn,
      image: primaryImage,
      priceUSD: product.basePriceUSD,
      sku: product.sku,
    });
  };

  const discountPercent =
    product.comparePriceUSD && product.comparePriceUSD > product.basePriceUSD
      ? Math.round(
          ((product.comparePriceUSD - product.basePriceUSD) / product.comparePriceUSD) * 100
        )
      : null;

  return (
    <div className="group relative bg-white border border-gray-100/90 rounded-2xl overflow-hidden hover:shadow-xl hover:border-gray-200 transition-all duration-300 flex flex-col justify-between">
      <div>
        {/* Thumbnail & Badges */}
        <div className="relative aspect-square bg-gray-50 overflow-hidden">
          <Link href={`/products/${product.slug}`}>
            <img
              src={primaryImage}
              alt={isBengali ? product.titleBn : product.titleEn}
              className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              loading="lazy"
            />
          </Link>

          {discountPercent && (
            <span className="absolute top-3 left-3 bg-brand-600 text-white text-[10px] font-black uppercase px-2 py-1 rounded-full shadow">
              {discountPercent}% {isBengali ? 'ছাড়' : 'OFF'}
            </span>
          )}

          {/* Quick Action overlay */}
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition flex items-center justify-center space-x-2 pointer-events-none">
            <Link
              href={`/products/${product.slug}`}
              className="pointer-events-auto p-2.5 bg-white text-gray-800 rounded-full hover:bg-brand-600 hover:text-white transition shadow-lg transform -translate-y-2 group-hover:translate-y-0 duration-300"
              title={t('storefront.view_details')}
            >
              <Eye className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-2">
          {product.category && (
            <p className="text-[11px] font-semibold text-brand-600 uppercase tracking-wider">
              {isBengali ? product.category.nameBn : product.category.nameEn}
            </p>
          )}

          <Link href={`/products/${product.slug}`}>
            <h3 className="text-sm font-bold text-gray-900 line-clamp-2 hover:text-brand-600 transition leading-snug">
              {isBengali ? product.titleBn : product.titleEn}
            </h3>
          </Link>

          {/* Rating */}
          <div className="flex items-center space-x-1 text-xs">
            <div className="flex items-center text-amber-400">
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
            <span className="font-bold text-gray-800 text-xs">
              {product.ratingAverage.toFixed(1)}
            </span>
            <span className="text-gray-400 text-[11px]">
              ({product.ratingCount})
            </span>
          </div>
        </div>
      </div>

      {/* Price & Add to Cart button */}
      <div className="p-4 pt-0 flex items-center justify-between border-t border-gray-50 mt-2">
        <div>
          <p className="text-sm font-black text-gray-900">
            {formatPrice(product.basePriceUSD)}
          </p>
          {product.comparePriceUSD && (
            <p className="text-[11px] text-gray-400 line-through">
              {formatPrice(product.comparePriceUSD)}
            </p>
          )}
        </div>

        <button
          onClick={handleQuickAdd}
          className="p-2.5 bg-brand-50 text-brand-700 hover:bg-brand-600 hover:text-white rounded-xl transition duration-200"
          title={t('storefront.add_to_cart')}
        >
          <ShoppingBag className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
