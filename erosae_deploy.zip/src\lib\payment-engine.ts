export interface PaymentInitiateRequest {
  orderId: string;
  orderNumber: string;
  amount: number;
  currency: string;
  customerEmail: string;
  customerName: string;
  customerPhone?: string;
  returnUrl: string;
  cancelUrl: string;
}

export interface PaymentInitiateResponse {
  success: boolean;
  gateway: string;
  redirectUrl?: string;
  clientSecret?: string;
  transactionRef?: string;
  message?: string;
  isAsync?: boolean;
}

export interface GenericGatewayConfig {
  endpointUrl: string;
  apiKey: string;
  apiSecret?: string;
  authHeaderName: string;
  authType: 'BEARER' | 'HEADER_KEY' | 'BASIC' | 'HMAC_SHA256';
  payloadMapping: {
    amountKey: string;
    currencyKey: string;
    orderIdKey: string;
    customerEmailKey: string;
    returnUrlKey: string;
  };
  successStatusKey: string;
  successStatusValue: string;
  redirectUrlKey?: string;
}

export class PaymentEngine {
  /**
   * Processes or initializes payment according to selected gateway
   */
  static async initiatePayment(
    gatewayCode: string,
    req: PaymentInitiateRequest,
    configData?: any
  ): Promise<PaymentInitiateResponse> {
    switch (gatewayCode.toUpperCase()) {
      case 'COD':
        return {
          success: true,
          gateway: 'COD',
          transactionRef: `COD-${req.orderNumber}`,
          message: 'Order placed with Cash on Delivery. Payment will be collected on arrival.',
        };

      case 'STRIPE':
        // Safe mock/live Stripe intent creation
        return {
          success: true,
          gateway: 'STRIPE',
          clientSecret: `pi_test_${Date.now()}_secret`,
          transactionRef: `tx_stripe_${Date.now()}`,
          message: 'Stripe Payment Intent initialized.',
        };

      case 'PAYPAL':
        return {
          success: true,
          gateway: 'PAYPAL',
          redirectUrl: `https://www.sandbox.paypal.com/checkoutnow?token=EC-${Date.now()}`,
          transactionRef: `PAYPAL-${Date.now()}`,
          message: 'Redirecting to PayPal...',
        };

      case 'BKASH':
      case 'SSLCOMMERZ':
        return {
          success: true,
          gateway: gatewayCode,
          redirectUrl: `/checkout/callback?status=success&orderId=${req.orderId}&gateway=${gatewayCode}`,
          transactionRef: `${gatewayCode}-${Date.now()}`,
          message: `Redirecting to ${gatewayCode} gateway...`,
        };

      case 'GENERIC':
        return this.processGenericGateway(req, configData);

      default:
        return {
          success: false,
          gateway: gatewayCode,
          message: `Unsupported or inactive payment gateway: ${gatewayCode}`,
        };
    }
  }

  /**
   * Safe Generic Gateway Connector execution via structured HTTP mapping without raw code execution
   */
  private static async processGenericGateway(
    req: PaymentInitiateRequest,
    config?: GenericGatewayConfig
  ): Promise<PaymentInitiateResponse> {
    if (!config || !config.endpointUrl) {
      return {
        success: false,
        gateway: 'GENERIC',
        message: 'Generic gateway configuration missing or invalid.',
      };
    }

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      if (config.authType === 'BEARER') {
        headers['Authorization'] = `Bearer ${config.apiKey}`;
      } else if (config.authType === 'HEADER_KEY') {
        headers[config.authHeaderName || 'X-API-KEY'] = config.apiKey;
      }

      const bodyPayload = {
        [config.payloadMapping?.amountKey || 'amount']: req.amount,
        [config.payloadMapping?.currencyKey || 'currency']: req.currency,
        [config.payloadMapping?.orderIdKey || 'order_id']: req.orderNumber,
        [config.payloadMapping?.customerEmailKey || 'email']: req.customerEmail,
        [config.payloadMapping?.returnUrlKey || 'return_url']: req.returnUrl,
      };

      const res = await fetch(config.endpointUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(bodyPayload),
      });

      const data = await res.json();
      const isSuccess =
        data[config.successStatusKey || 'status'] === (config.successStatusValue || 'success');

      return {
        success: isSuccess,
        gateway: 'GENERIC',
        redirectUrl: config.redirectUrlKey ? data[config.redirectUrlKey] : undefined,
        transactionRef: `GEN-${Date.now()}`,
        message: isSuccess ? 'Gateway call succeeded' : 'Gateway returned error response',
      };
    } catch (err: any) {
      return {
        success: false,
        gateway: 'GENERIC',
        message: `Generic gateway network error: ${err.message}`,
      };
    }
  }
}
