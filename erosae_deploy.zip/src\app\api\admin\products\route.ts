import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      titleEn,
      titleBn,
      slug,
      descriptionEn,
      descriptionBn,
      basePriceUSD,
      sku,
      brand,
      categoryId,
      image,
      stock,
      customFields,
    } = body;

    const product = await db.product.create({
      data: {
        titleEn,
        titleBn,
        slug: slug || `${sku.toLowerCase()}-${Date.now()}`,
        descriptionEn: descriptionEn || titleEn,
        descriptionBn: descriptionBn || titleBn,
        basePriceUSD: parseFloat(basePriceUSD),
        sku,
        brand: brand || 'Erosae',
        categoryId,
        images: {
          create: [
            {
              url: image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600',
              altEn: titleEn,
              altBn: titleBn,
              isPrimary: true,
            },
          ],
        },
        variants: {
          create: [
            {
              sku: `${sku}-STD`,
              nameEn: 'Standard',
              nameBn: 'স্ট্যান্ডার্ড',
              priceUSD: parseFloat(basePriceUSD),
              stockQuantity: parseInt(stock) || 50,
              attributes: '{}',
            },
          ],
        },
        customFields: {
          create: customFields?.map((cf: any) => ({
            fieldKey: cf.key,
            labelEn: cf.labelEn,
            labelBn: cf.labelBn,
            valueEn: cf.valEn,
            valueBn: cf.valBn,
          })) || [],
        },
      },
      include: {
        images: true,
        variants: true,
        customFields: true,
      },
    });

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    console.error('Admin product creation error:', error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
