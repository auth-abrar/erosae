export interface AdminModule {
  id: string;
  name: string;
  description: string;
  icon: string;
  route: string;
  permissionRequired: string;
  hasWidget: boolean;
  widgetComponent?: string;
  isCore: boolean;
  version: string;
}

export const ADMIN_MODULE_REGISTRY: AdminModule[] = [
  {
    id: 'dashboard',
    name: 'Dashboard Overview',
    description: 'Executive analytics, real-time sales metrics, and urgent alerts',
    icon: 'LayoutDashboard',
    route: '/admin',
    permissionRequired: 'dashboard.view',
    hasWidget: true,
    widgetComponent: 'DashboardStatsWidget',
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'products',
    name: 'Product Management',
    description: 'Bilingual catalog, variants, stock, custom fields and bulk CSV import',
    icon: 'Package',
    route: '/admin/products',
    permissionRequired: 'products.view',
    hasWidget: true,
    widgetComponent: 'LowStockAlertWidget',
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'orders',
    name: 'Orders & Invoices',
    description: 'Order processing, bilingual printable invoices, status updates, and tracking',
    icon: 'ShoppingBag',
    route: '/admin/orders',
    permissionRequired: 'orders.view',
    hasWidget: true,
    widgetComponent: 'RecentOrdersWidget',
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'customers',
    name: 'Customer Profiles',
    description: 'Registered buyers, order histories, and support notes',
    icon: 'Users',
    route: '/admin/customers',
    permissionRequired: 'customers.view',
    hasWidget: false,
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'payments',
    name: 'Payment Gateways',
    description: 'Manage Stripe, PayPal, COD, SSLCommerz and Generic Custom Connectors',
    icon: 'CreditCard',
    route: '/admin/payments',
    permissionRequired: 'gateways.manage',
    hasWidget: false,
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'currencies',
    name: 'Multi-Currency & FX',
    description: 'Manage 10 regional currencies, decimal precision and exchange rates',
    icon: 'DollarSign',
    route: '/admin/currencies',
    permissionRequired: 'currencies.manage',
    hasWidget: true,
    widgetComponent: 'CurrencyBreakdownWidget',
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'translations',
    name: 'Content & Translations',
    description: 'Live editor for English and natural Bengali storefront copy & policies',
    icon: 'Languages',
    route: '/admin/translations',
    permissionRequired: 'translations.manage',
    hasWidget: false,
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'roles',
    name: 'Staff & Permissions',
    description: 'Custom staff roles, RBAC matrix, and 2FA configuration',
    icon: 'ShieldCheck',
    route: '/admin/roles',
    permissionRequired: 'roles.manage',
    hasWidget: false,
    isCore: true,
    version: '1.0.0',
  },
  {
    id: 'shipping',
    name: 'Shipping & Tax Rules',
    description: 'Regional delivery fees, free shipping thresholds, and tax policies',
    icon: 'Truck',
    route: '/admin/shipping',
    permissionRequired: 'shipping.manage',
    hasWidget: false,
    isCore: true,
    version: '1.0.0',
  },
];
