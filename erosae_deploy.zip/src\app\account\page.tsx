'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import {
  User,
  ShoppingBag,
  Heart,
  MapPin,
  Shield,
  FileText,
  Clock,
  ChevronRight,
  Eye,
} from 'lucide-react';

export default function AccountPage() {
  const { locale, formatPrice, t } = useStore();
  const isBengali = locale === 'bn';

  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'addresses'>('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/orders')
      .then((r) => r.json())
      .then((data) => {
        if (data.success) setOrders(data.orders);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center space-x-4 mb-8">
        <div className="w-14 h-14 bg-brand-50 text-brand-700 rounded-2xl flex items-center justify-center font-bold text-xl">
          <User className="w-7 h-7" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-gray-900">
            {t('account.dashboard')}
          </h1>
          <p className="text-xs text-gray-500 mt-0.5">
            {isBengali
              ? 'আপনার অর্ডার ট্র্যাকিং ও প্রোফাইল ব্যবস্থাপনা'
              : 'Manage your purchases, shipping addresses and preferences'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-3 space-y-2">
          <div className="bg-white border border-gray-100 rounded-2xl p-2 shadow-sm space-y-1">
            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition ${
                activeTab === 'orders'
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>{t('account.orders')}</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition ${
                activeTab === 'profile'
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <User className="w-4 h-4" />
              <span>{t('account.profile')}</span>
            </button>

            <button
              onClick={() => setActiveTab('addresses')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-xs font-bold transition ${
                activeTab === 'addresses'
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>{t('account.addresses')}</span>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="lg:col-span-9">
          {activeTab === 'orders' && (
            <div className="bg-white border border-gray-100 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
              <h2 className="text-base font-bold text-gray-900">{t('account.orders')}</h2>

              {loading ? (
                <div className="space-y-4 animate-pulse">
                  {[1, 2, 3].map((n) => (
                    <div key={n} className="h-20 bg-gray-100 rounded-2xl" />
                  ))}
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-16">
                  <ShoppingBag className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 font-medium">
                    {isBengali ? 'আপনার কোনো পূর্ববর্তী অর্ডার নেই।' : 'No orders placed yet.'}
                  </p>
                  <Link
                    href="/products"
                    className="mt-4 inline-block px-6 py-2.5 bg-brand-600 text-white rounded-full text-xs font-bold hover:bg-brand-700 transition"
                  >
                    {t('cart.continue_shopping')}
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((ord) => (
                    <div
                      key={ord.id}
                      className="border border-gray-100 rounded-2xl p-4 sm:p-5 hover:border-gray-200 transition flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gray-50/50"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-xs text-gray-900 font-mono">
                            {ord.orderNumber}
                          </span>
                          <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                            {ord.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-500 flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>
                            {new Date(ord.createdAt).toLocaleDateString(
                              isBengali ? 'bn-BD' : 'en-US',
                              { year: 'numeric', month: 'short', day: 'numeric' }
                            )}
                          </span>
                          <span>• {ord.items?.length || 1} items</span>
                        </p>
                      </div>

                      <div className="flex items-center space-x-4 w-full sm:w-auto justify-between sm:justify-end">
                        <span className="font-black text-sm text-gray-900">
                          {formatPrice(ord.totalAmount)}
                        </span>
                        <Link
                          href={`/checkout/success?orderId=${ord.id}`}
                          className="px-4 py-2 bg-white border border-gray-200 text-gray-700 hover:text-brand-600 hover:border-brand-600 rounded-xl text-xs font-bold transition flex items-center space-x-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{isBengali ? 'ইনভয়েস' : 'Invoice'}</span>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="bg-white border border-gray-100 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
              <h2 className="text-base font-bold text-gray-900">{t('account.profile')}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-gray-500 mb-1">Full Name</label>
                  <input
                    type="text"
                    defaultValue="Ruhul Amin"
                    className="w-full px-3 py-2 border rounded-xl bg-gray-50 text-gray-800"
                  />
                </div>
                <div>
                  <label className="block text-gray-500 mb-1">Email</label>
                  <input
                    type="email"
                    defaultValue="customer@erosae.com"
                    className="w-full px-3 py-2 border rounded-xl bg-gray-50 text-gray-800"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'addresses' && (
            <div className="bg-white border border-gray-100 rounded-3xl p-6 sm:p-8 shadow-sm space-y-4">
              <h2 className="text-base font-bold text-gray-900">{t('account.addresses')}</h2>
              <div className="p-4 border border-dashed border-gray-300 rounded-2xl text-xs text-gray-500">
                <p className="font-bold text-gray-800">Default Shipping Address</p>
                <p className="mt-1">House 12, Road 4, Sector 7, Uttara, Dhaka, Bangladesh</p>
                <p>Phone: +880 1700 000000</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
