'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { ProductCard } from '@/components/storefront/ProductCard';
import {
  ArrowRight,
  Sparkles,
  Zap,
  Flame,
  ShieldCheck,
  TrendingUp,
  Package,
} from 'lucide-react';

export default function HomePage() {
  const { locale, t, formatPrice } = useStore();
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const isBengali = locale === 'bn';

  useEffect(() => {
    async function fetchData() {
      try {
        const [prodRes, catRes] = await Promise.all([
          fetch('/api/products?featured=true').then((r) => r.json()),
          fetch('/api/categories').then((r) => r.json()),
        ]);

        if (prodRes.success) setProducts(prodRes.products);
        if (catRes.success) setCategories(catRes.categories);
      } catch (err) {
        console.error('Failed to load home data', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  return (
    <div className="space-y-16 pb-20">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-950 via-gray-900 to-black text-white pt-16 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-[radial-gradient(#d75a6a_1px,transparent_1px)] [background-size:24px_24px] opacity-15" />
        <div className="relative max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-brand-900/60 border border-brand-500/30 text-xs font-semibold text-brand-300">
              <Sparkles className="w-3.5 h-3.5 text-gold-500 animate-pulse" />
              <span>{t('hero.badge')}</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
              {t('hero.title_1')}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 via-rose-300 to-gold-500">
                {t('hero.title_2')}
              </span>
            </h1>

            <p className="text-gray-300 text-sm sm:text-base leading-relaxed max-w-xl">
              {t('hero.subtitle')}
            </p>

            <div className="pt-4 flex flex-wrap gap-4 items-center">
              <Link
                href="/products"
                className="px-8 py-4 bg-gradient-to-r from-brand-600 to-brand-700 hover:from-brand-500 hover:to-brand-600 text-white rounded-full font-bold text-sm transition-all duration-200 shadow-lg shadow-brand-600/30 flex items-center space-x-2"
              >
                <span>{t('hero.shop_now')}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/products?deals=true"
                className="px-6 py-4 bg-white/10 hover:bg-white/15 text-white border border-white/20 rounded-full font-semibold text-sm transition"
              >
                {t('hero.view_deals')}
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="pt-8 border-t border-white/10 grid grid-cols-3 gap-6 text-left">
              <div>
                <p className="text-2xl font-black text-white">1,000+</p>
                <p className="text-xs text-gray-400 mt-0.5">{isBengali ? 'প্রিমিয়াম প্রোডাক্ট' : 'Curated Items'}</p>
              </div>
              <div>
                <p className="text-2xl font-black text-gold-500">10</p>
                <p className="text-xs text-gray-400 mt-0.5">{isBengali ? 'আন্তর্জাতিক কারেন্সি' : 'Supported Currencies'}</p>
              </div>
              <div>
                <p className="text-2xl font-black text-brand-400">100%</p>
                <p className="text-xs text-gray-400 mt-0.5">{isBengali ? 'নিরাপদ ডেলিভারি' : 'Buyer Guarantee'}</p>
              </div>
            </div>
          </div>

          {/* Hero Featured Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm rounded-3xl p-4 bg-gradient-to-b from-white/15 to-white/5 border border-white/20 backdrop-blur-xl shadow-2xl">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-gray-800 relative">
                <img
                  src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80"
                  alt="Headphones"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 left-3 bg-brand-600 text-white text-xs font-bold px-2.5 py-1 rounded-full">
                  {isBengali ? 'স্পেশাল অফার' : 'Trending'}
                </span>
              </div>
              <div className="p-4 space-y-2">
                <h3 className="font-bold text-white text-base">
                  {isBengali
                    ? 'অরা ওয়্যারলেস হেডফোন প্রো'
                    : 'Aura Wireless Headphones Pro'}
                </h3>
                <p className="text-xs text-gray-300">
                  {isBengali
                    ? 'হাইব্রিড নয়েজ ক্যানসেলেশন ও ৪০ ঘণ্টার ব্যাটারি'
                    : 'Hybrid Noise Cancellation with 40h battery'}
                </p>
                <div className="flex justify-between items-center pt-2">
                  <p className="text-lg font-black text-gold-500">
                    {formatPrice(149.99)}
                  </p>
                  <Link
                    href="/products/aura-wireless-headphones-pro"
                    className="px-4 py-2 bg-white text-gray-900 font-bold text-xs rounded-xl hover:bg-gray-100 transition"
                  >
                    {t('storefront.view_details')}
                  </Link>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 2. Featured Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              {t('storefront.featured_categories')}
            </h2>
            <p className="text-xs text-gray-500 mt-1">
              {isBengali
                ? 'পছন্দের ক্যাটাগরি থেকে সহজে কেনাকাটা করুন'
                : 'Browse our specialized departments and collections'}
            </p>
          </div>
          <Link
            href="/products"
            className="text-xs font-bold text-brand-600 hover:text-brand-700 flex items-center space-x-1"
          >
            <span>{isBengali ? 'সব ক্যাটাগরি' : 'View All'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/products?category=${cat.slug}`}
              className="group relative rounded-2xl overflow-hidden bg-white border border-gray-100 p-4 shadow-sm hover:shadow-xl hover:border-brand-500/30 transition duration-300 flex flex-col items-center text-center"
            >
              <div className="w-24 h-24 rounded-full overflow-hidden mb-4 bg-gray-50 border-2 border-gray-100 group-hover:scale-105 transition duration-300">
                <img
                  src={cat.image}
                  alt={isBengali ? cat.nameBn : cat.nameEn}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-bold text-sm text-gray-900 group-hover:text-brand-600 transition">
                {isBengali ? cat.nameBn : cat.nameEn}
              </h3>
              <p className="text-[11px] text-gray-400 mt-1">
                {cat._count?.products || 0} {isBengali ? 'টি পণ্য' : 'Items'}
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* 3. Featured & Trending Products Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <div className="flex items-center space-x-2">
            <Flame className="w-6 h-6 text-brand-600" />
            <div>
              <h2 className="text-2xl font-black text-gray-900 tracking-tight">
                {t('storefront.trending_now')}
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                {isBengali
                  ? 'গ্রাহকদের পছন্দের শীর্ষে থাকা জনপ্রিয় প্রোডাক্টস'
                  : 'Highest rated and most demanded merchandise this week'}
              </p>
            </div>
          </div>

          <Link
            href="/products"
            className="text-xs font-bold text-brand-600 hover:text-brand-700 flex items-center space-x-1"
          >
            <span>{isBengali ? 'সবগুলো দেখুন' : 'Explore All'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="h-80 bg-gray-100 animate-pulse rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* 4. Promotional Banner Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-brand-900 to-brand-700 text-white p-8 sm:p-12 relative overflow-hidden flex flex-col md:flex-row items-center justify-between shadow-2xl">
          <div className="space-y-4 max-w-lg z-10">
            <span className="px-3 py-1 bg-white/20 text-white text-xs font-bold rounded-full uppercase tracking-wider">
              {isBengali ? 'বিশেষ ডিসকাউন্ট' : 'Limited Time Offer'}
            </span>
            <h2 className="text-3xl font-black">
              {isBengali
                ? 'প্রথম অর্ডারে পান বিশেষ ১০% ছাড়'
                : 'Enjoy 10% Extra Discount on Your First Order'}
            </h2>
            <p className="text-xs sm:text-sm text-brand-100 leading-relaxed">
              {isBengali
                ? 'চেকআউটে প্রোমোকোড EROSAE10 ব্যবহার করুন এবং নিশ্চিত ক্যাশব্যাক ও দ্রুত হোম ডেলিভারি সুবিধা উপভোগ করুন।'
                : 'Use promo code EROSAE10 at checkout to unlock instant discounts with Cash on Delivery and multiple payment options.'}
            </p>
            <div className="pt-2">
              <Link
                href="/products"
                className="px-6 py-3 bg-white text-brand-800 rounded-full font-bold text-xs hover:bg-gray-100 transition inline-flex items-center space-x-2"
              >
                <span>{isBengali ? 'কেনাকাটা করুন' : 'Claim Discount'}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
