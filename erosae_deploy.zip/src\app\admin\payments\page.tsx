'use client';

import React, { useState } from 'react';
import {
  CreditCard,
  CheckCircle,
  ShieldCheck,
  Key,
  Sliders,
  Globe,
  Lock,
  Plus,
  Save,
} from 'lucide-react';

export default function AdminPaymentsPage() {
  const [gateways, setGateways] = useState([
    {
      code: 'COD',
      name: 'Cash on Delivery (COD)',
      isEnabled: true,
      isLiveMode: true,
      description: 'Collect cash upon physical package delivery. Most popular in South Asia.',
      supportedCurrencies: 'BDT, USD, AED, SAR, INR, PKR, QAR, OMR, KWD, BHD',
    },
    {
      code: 'STRIPE',
      name: 'Stripe Global Card Gateway',
      isEnabled: true,
      isLiveMode: false,
      publishableKey: 'pk_test_********************',
      secretKey: 'sk_test_********************',
      supportedCurrencies: 'USD, AED, SAR, QAR, EUR, GBP',
    },
    {
      code: 'BKASH',
      name: 'bKash / Mobile Wallet (MFS)',
      isEnabled: true,
      isLiveMode: false,
      appKey: 'bKash_demo_key_***',
      appSecret: 'bKash_demo_secret_***',
      supportedCurrencies: 'BDT',
    },
    {
      code: 'PAYPAL',
      name: 'PayPal Global Payments',
      isEnabled: true,
      isLiveMode: false,
      clientId: 'paypal_client_id_***',
      supportedCurrencies: 'USD, EUR, GBP, AUD',
    },
  ]);

  // Generic Gateway Form state
  const [genericGateway, setGenericGateway] = useState({
    name: 'Custom Regional Aggregator',
    endpointUrl: 'https://api.gateway.example.com/v1/checkout',
    authType: 'BEARER',
    apiKey: 'sec_live_****************',
    authHeaderName: 'Authorization',
    amountKey: 'amount',
    currencyKey: 'currency',
    orderIdKey: 'order_id',
    successKey: 'status',
    successValue: 'success',
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const toggleGateway = (index: number) => {
    const updated = [...gateways];
    updated[index].isEnabled = !updated[index].isEnabled;
    setGateways(updated);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-6">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center space-x-2">
            <CreditCard className="w-6 h-6 text-brand-500" />
            <span>Payment Gateway Hub</span>
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Configure pre-built gateways (Stripe, PayPal, COD, bKash) and custom generic connectors safely.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-brand-600/20 transition"
        >
          <Save className="w-4 h-4" />
          <span>Save Gateway Configurations</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 rounded-2xl text-xs font-bold flex items-center space-x-2">
          <CheckCircle className="w-4 h-4" />
          <span>Payment Gateway settings updated and encrypted securely.</span>
        </div>
      )}

      {/* Pre-built Gateways Grid */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-gray-200 uppercase tracking-wider">
          Pre-Built Gateway Modules
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {gateways.map((gw, idx) => (
            <div
              key={gw.code}
              className="bg-gray-900 border border-gray-800 rounded-3xl p-6 space-y-4"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-white text-sm">{gw.name}</h3>
                  <p className="text-[11px] text-gray-400 mt-0.5">{gw.supportedCurrencies}</p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gw.isEnabled}
                    onChange={() => toggleGateway(idx)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-600"></div>
                </label>
              </div>

              {gw.code === 'STRIPE' && (
                <div className="space-y-2 text-xs">
                  <div>
                    <label className="block text-gray-500 text-[10px] uppercase font-bold">
                      Publishable Key
                    </label>
                    <input
                      type="text"
                      defaultValue={gw.publishableKey}
                      className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-gray-300 font-mono text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-500 text-[10px] uppercase font-bold">
                      Secret Key (Masked)
                    </label>
                    <input
                      type="password"
                      defaultValue={gw.secretKey}
                      className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-gray-300 font-mono text-[11px]"
                    />
                  </div>
                </div>
              )}

              {gw.code === 'BKASH' && (
                <div className="space-y-2 text-xs">
                  <div>
                    <label className="block text-gray-500 text-[10px] uppercase font-bold">
                      App Key
                    </label>
                    <input
                      type="text"
                      defaultValue={gw.appKey}
                      className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-gray-300 font-mono text-[11px]"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-[11px] text-gray-500 border-t border-gray-800 pt-3">
                <span>Mode: {gw.isLiveMode ? '🟢 Live Production' : '🟡 Test / Sandbox'}</span>
                <span className="text-emerald-400 font-semibold">Ready</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Structured Generic Gateway Connector */}
      <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center space-x-3 border-b border-gray-800 pb-4">
          <div className="p-2 bg-brand-950 text-brand-400 rounded-xl">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Generic Custom Gateway Connector</h2>
            <p className="text-xs text-gray-400">
              Safe structured configuration for external payment aggregators (no server code execution).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-gray-400 mb-1 font-semibold">Gateway / Provider Name</label>
            <input
              type="text"
              value={genericGateway.name}
              onChange={(e) => setGenericGateway({ ...genericGateway, name: e.target.value })}
              className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white"
            />
          </div>

          <div>
            <label className="block text-gray-400 mb-1 font-semibold">API Endpoint URL</label>
            <input
              type="text"
              value={genericGateway.endpointUrl}
              onChange={(e) => setGenericGateway({ ...genericGateway, endpointUrl: e.target.value })}
              className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white font-mono"
            />
          </div>

          <div>
            <label className="block text-gray-400 mb-1 font-semibold">Authentication Type</label>
            <select
              value={genericGateway.authType}
              onChange={(e) => setGenericGateway({ ...genericGateway, authType: e.target.value })}
              className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white"
            >
              <option value="BEARER">Bearer Token (Authorization: Bearer ...)</option>
              <option value="HEADER_KEY">Custom API Header (e.g. X-API-KEY)</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-400 mb-1 font-semibold">API Key / Secret</label>
            <input
              type="password"
              value={genericGateway.apiKey}
              onChange={(e) => setGenericGateway({ ...genericGateway, apiKey: e.target.value })}
              className="w-full px-3 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white font-mono"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
