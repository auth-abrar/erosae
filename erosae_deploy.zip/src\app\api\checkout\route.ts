import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PaymentEngine } from '@/lib/payment-engine';
import { SUPPORTED_CURRENCIES, convertFromUSD } from '@/lib/currency';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      cart,
      shippingAddress,
      paymentMethod,
      currencyCode = 'USD',
      customerNotes,
      couponCode,
    } = body;

    if (!cart || !Array.isArray(cart) || cart.length === 0) {
      return NextResponse.json(
        { success: false, message: 'Cart is empty.' },
        { status: 400 }
      );
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.addressLine1) {
      return NextResponse.json(
        { success: false, message: 'Incomplete delivery address.' },
        { status: 400 }
      );
    }

    // 1. Calculate items & verify prices
    let subtotalUSD = 0;
    const orderItemsData = [];

    const currencyConfig = SUPPORTED_CURRENCIES[currencyCode] || SUPPORTED_CURRENCIES.USD;
    const exchangeRate = currencyConfig.exchangeRateToUSD;

    for (const item of cart) {
      const product = await db.product.findUnique({
        where: { id: item.productId },
        include: { variants: true },
      });

      if (!product) {
        return NextResponse.json(
          { success: false, message: `Product not found: ${item.titleEn}` },
          { status: 400 }
        );
      }

      let unitPriceUSD = product.basePriceUSD;
      if (item.variantId) {
        const variant = product.variants.find((v) => v.id === item.variantId);
        if (variant) unitPriceUSD = variant.priceUSD;
      }

      const itemTotalUSD = unitPriceUSD * item.quantity;
      subtotalUSD += itemTotalUSD;

      const unitPriceLocal = convertFromUSD(unitPriceUSD, currencyCode, exchangeRate);
      const totalPriceLocal = convertFromUSD(itemTotalUSD, currencyCode, exchangeRate);

      orderItemsData.push({
        productId: product.id,
        variantId: item.variantId || null,
        titleEn: product.titleEn,
        titleBn: product.titleBn,
        sku: item.sku || product.sku,
        unitPriceUSD,
        unitPriceLocal,
        quantity: item.quantity,
        totalPriceUSD: itemTotalUSD,
        totalPriceLocal,
      });
    }

    // 2. Shipping calculation
    const shippingUSD = subtotalUSD > 50 ? 0.0 : 5.0; // Free shipping over $50
    const discountUSD = couponCode?.toUpperCase() === 'EROSAE10' ? subtotalUSD * 0.1 : 0.0;
    const totalUSD = Math.max(0, subtotalUSD + shippingUSD - discountUSD);

    const totalLocal = convertFromUSD(totalUSD, currencyCode, exchangeRate);

    // 3. Create Order in Database
    const orderNumber = `ERO-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const newOrder = await db.order.create({
      data: {
        orderNumber,
        guestEmail: shippingAddress.email,
        guestPhone: shippingAddress.phone,
        guestName: shippingAddress.fullName,
        status: 'PENDING',
        paymentStatus: paymentMethod === 'COD' ? 'PENDING' : 'PENDING',
        paymentMethod: paymentMethod || 'COD',
        currencyCode,
        exchangeRate,
        subtotalAmount: subtotalUSD,
        shippingAmount: shippingUSD,
        discountAmount: discountUSD,
        totalAmount: totalUSD,
        shippingAddress: JSON.stringify(shippingAddress),
        customerNotes: customerNotes || null,
        items: {
          create: orderItemsData,
        },
      },
      include: {
        items: true,
      },
    });

    // 4. Initialize Payment through Gateway Engine
    const paymentResult = await PaymentEngine.initiatePayment(paymentMethod, {
      orderId: newOrder.id,
      orderNumber: newOrder.orderNumber,
      amount: totalLocal,
      currency: currencyCode,
      customerEmail: shippingAddress.email,
      customerName: shippingAddress.fullName,
      customerPhone: shippingAddress.phone,
      returnUrl: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/checkout/success?orderId=${newOrder.id}`,
      cancelUrl: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/checkout?status=cancel`,
    });

    // Record Payment Entry
    await db.payment.create({
      data: {
        orderId: newOrder.id,
        gatewayCode: paymentMethod,
        transactionRef: paymentResult.transactionRef,
        amount: totalLocal,
        currency: currencyCode,
        status: paymentMethod === 'COD' ? 'PENDING' : (paymentResult.success ? 'PENDING' : 'FAILED'),
        gatewayResponse: JSON.stringify(paymentResult),
      },
    });

    return NextResponse.json({
      success: true,
      order: newOrder,
      payment: paymentResult,
      redirectUrl: paymentResult.redirectUrl || `/checkout/success?orderId=${newOrder.id}`,
    });
  } catch (error: any) {
    console.error('Checkout error:', error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
