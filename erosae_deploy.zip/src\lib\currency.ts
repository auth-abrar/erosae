export interface CurrencyConfig {
  code: string;
  nameEn: string;
  nameBn: string;
  symbol: string;
  decimalPlaces: number;
  exchangeRateToUSD: number; // units per 1 USD
  isDefault?: boolean;
}

export const SUPPORTED_CURRENCIES: Record<string, CurrencyConfig> = {
  USD: {
    code: 'USD',
    nameEn: 'US Dollar',
    nameBn: 'ইউএস ডলার',
    symbol: '$',
    decimalPlaces: 2,
    exchangeRateToUSD: 1.0,
    isDefault: true,
  },
  BDT: {
    code: 'BDT',
    nameEn: 'Bangladeshi Taka',
    nameBn: 'বাংলাদেশী টাকা',
    symbol: '৳',
    decimalPlaces: 2,
    exchangeRateToUSD: 119.50,
  },
  INR: {
    code: 'INR',
    nameEn: 'Indian Rupee',
    nameBn: 'ভারতীয় রুপি',
    symbol: '₹',
    decimalPlaces: 2,
    exchangeRateToUSD: 83.90,
  },
  PKR: {
    code: 'PKR',
    nameEn: 'Pakistani Rupee',
    nameBn: 'পাকিস্তানি রুপি',
    symbol: '₨',
    decimalPlaces: 2,
    exchangeRateToUSD: 278.50,
  },
  AED: {
    code: 'AED',
    nameEn: 'UAE Dirham',
    nameBn: 'সংযুক্ত আরব আমিরাত দিরহাম',
    symbol: 'د.إ',
    decimalPlaces: 2,
    exchangeRateToUSD: 3.67,
  },
  SAR: {
    code: 'SAR',
    nameEn: 'Saudi Riyal',
    nameBn: 'সৌদি রিয়াল',
    symbol: '﷼',
    decimalPlaces: 2,
    exchangeRateToUSD: 3.75,
  },
  QAR: {
    code: 'QAR',
    nameEn: 'Qatari Riyal',
    nameBn: 'কাতারি রিয়াল',
    symbol: '﷼',
    decimalPlaces: 2,
    exchangeRateToUSD: 3.64,
  },
  OMR: {
    code: 'OMR',
    nameEn: 'Omani Rial',
    nameBn: 'ওমানি রিয়াল',
    symbol: 'ر.ع.',
    decimalPlaces: 3, // 3 decimal places
    exchangeRateToUSD: 0.385,
  },
  KWD: {
    code: 'KWD',
    nameEn: 'Kuwaiti Dinar',
    nameBn: 'কুয়েতি দিনার',
    symbol: 'د.ك',
    decimalPlaces: 3, // 3 decimal places
    exchangeRateToUSD: 0.306,
  },
  BHD: {
    code: 'BHD',
    nameEn: 'Bahraini Dinar',
    nameBn: 'বাহরাইনি দিনার',
    symbol: '.د.ب',
    decimalPlaces: 3, // 3 decimal places
    exchangeRateToUSD: 0.377,
  },
};

/**
 * Converts a base USD amount to target currency.
 */
export function convertFromUSD(amountUSD: number, targetCurrencyCode: string, customRate?: number): number {
  const config = SUPPORTED_CURRENCIES[targetCurrencyCode] || SUPPORTED_CURRENCIES.USD;
  const rate = customRate || config.exchangeRateToUSD;
  const converted = amountUSD * rate;
  const factor = Math.pow(10, config.decimalPlaces);
  return Math.round(converted * factor) / factor;
}

/**
 * Formats a currency value with appropriate decimals and symbol.
 */
export function formatCurrency(
  amountUSD: number,
  currencyCode: string = 'USD',
  locale: string = 'en',
  customRate?: number
): string {
  const config = SUPPORTED_CURRENCIES[currencyCode] || SUPPORTED_CURRENCIES.USD;
  const converted = convertFromUSD(amountUSD, currencyCode, customRate);
  
  const formattedNumber = converted.toLocaleString(locale === 'bn' ? 'bn-BD' : 'en-US', {
    minimumFractionDigits: config.decimalPlaces,
    maximumFractionDigits: config.decimalPlaces,
  });

  if (locale === 'bn') {
    return `${config.symbol} ${formattedNumber}`;
  }
  return `${config.symbol}${formattedNumber} ${config.code}`;
}
