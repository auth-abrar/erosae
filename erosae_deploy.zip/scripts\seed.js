const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Erosae.com E-Commerce database...');

  // 1. Seed Currencies
  const currencies = [
    { code: 'USD', nameEn: 'US Dollar', nameBn: 'ইউএস ডলার', symbol: '$', decimalPlaces: 2, exchangeRateToUSD: 1.0, isDefault: true },
    { code: 'BDT', nameEn: 'Bangladeshi Taka', nameBn: 'বাংলাদেশী টাকা', symbol: '৳', decimalPlaces: 2, exchangeRateToUSD: 119.50 },
    { code: 'INR', nameEn: 'Indian Rupee', nameBn: 'ভারতীয় রুপি', symbol: '₹', decimalPlaces: 2, exchangeRateToUSD: 83.90 },
    { code: 'PKR', nameEn: 'Pakistani Rupee', nameBn: 'পাকিস্তানি রুপি', symbol: '₨', decimalPlaces: 2, exchangeRateToUSD: 278.50 },
    { code: 'AED', nameEn: 'UAE Dirham', nameBn: 'সংযুক্ত আরব আমিরাত দিরহাম', symbol: 'د.إ', decimalPlaces: 2, exchangeRateToUSD: 3.67 },
    { code: 'SAR', nameEn: 'Saudi Riyal', nameBn: 'সৌদি রিয়াল', symbol: '﷼', decimalPlaces: 2, exchangeRateToUSD: 3.75 },
    { code: 'QAR', nameEn: 'Qatari Riyal', nameBn: 'কাতারি রিয়াল', symbol: '﷼', decimalPlaces: 2, exchangeRateToUSD: 3.64 },
    { code: 'OMR', nameEn: 'Omani Rial', nameBn: 'ওমানি রিয়াল', symbol: 'ر.ع.', decimalPlaces: 3, exchangeRateToUSD: 0.385 },
    { code: 'KWD', nameEn: 'Kuwaiti Dinar', nameBn: 'কুয়েতি দিনার', symbol: 'د.ك', decimalPlaces: 3, exchangeRateToUSD: 0.306 },
    { code: 'BHD', nameEn: 'Bahraini Dinar', nameBn: 'বাহরাইনি দিনার', symbol: '.د.ব', decimalPlaces: 3, exchangeRateToUSD: 0.377 },
  ];

  for (const curr of currencies) {
    await prisma.currency.upsert({
      where: { code: curr.code },
      update: curr,
      create: curr,
    });
  }
  console.log('Currencies seeded.');

  // 2. Roles & Permissions
  const superAdminRole = await prisma.role.upsert({
    where: { name: 'Super Admin' },
    update: {},
    create: {
      name: 'Super Admin',
      description: 'Full master access to all store operations, payments, and settings',
    },
  });

  // 3. Admin User
  const passwordHash = await bcrypt.hash('Admin@Erosae2026!', 12);
  await prisma.adminUser.upsert({
    where: { email: 'admin@erosae.com' },
    update: {
      passwordHash,
      roleId: superAdminRole.id,
    },
    create: {
      name: 'Master Administrator',
      email: 'admin@erosae.com',
      passwordHash,
      roleId: superAdminRole.id,
    },
  });
  console.log('Admin user seeded: admin@erosae.com / Admin@Erosae2026!');

  // 4. Categories
  const catElectronics = await prisma.category.upsert({
    where: { slug: 'electronics' },
    update: {},
    create: {
      nameEn: 'Electronics & Gadgets',
      nameBn: 'ইলেকট্রনিক্স ও গ্যাজেটস',
      slug: 'electronics',
      descriptionEn: 'Smartphones, audio, smart watches, and accessories',
      descriptionBn: 'স্মার্টফোন, অডিও, স্মার্টওয়াচ এবং প্রয়োজনীয় গ্যাজেট',
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80',
    },
  });

  const catFashion = await prisma.category.upsert({
    where: { slug: 'fashion' },
    update: {},
    create: {
      nameEn: 'Fashion & Apparel',
      nameBn: 'ফ্যাশন ও পোশাক',
      slug: 'fashion',
      descriptionEn: 'Premium clothing, shoes, and luxury accessories',
      descriptionBn: 'আকর্ষণীয় পোশাক, জুতো এবং লাইফস্টাইল কালেকশন',
      image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=600&auto=format&fit=crop&q=80',
    },
  });

  const catHome = await prisma.category.upsert({
    where: { slug: 'home-living' },
    update: {},
    create: {
      nameEn: 'Home & Living',
      nameBn: 'গৃহসজ্জা ও লাইফস্টাইল',
      slug: 'home-living',
      descriptionEn: 'Decor, kitchenware, and modern appliances',
      descriptionBn: 'ঘরের ডেকোরেশন, কিচেন সামগ্রী ও আধুনিক হোম অ্যাপ্লায়েন্স',
      image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=80',
    },
  });

  const catBeauty = await prisma.category.upsert({
    where: { slug: 'beauty-health' },
    update: {},
    create: {
      nameEn: 'Beauty & Personal Care',
      nameBn: 'বিউটি ও পার্সোনাল কেয়ার',
      slug: 'beauty-health',
      descriptionEn: 'Skincare, fragrances, and organic wellness',
      descriptionBn: 'স্কিনকেয়ার, সুগন্ধি এবং স্বাস্থ্য সুরক্ষা সামগ্রী',
      image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600&auto=format&fit=crop&q=80',
    },
  });

  console.log('Categories seeded.');

  // 5. Products
  const products = [
    {
      titleEn: 'Aura Wireless Noise-Cancelling Headphones Pro',
      titleBn: 'অরা ওয়্যারলেস নয়েজ-ক্যানসেলিং হেডফোন প্রো',
      slug: 'aura-wireless-headphones-pro',
      descriptionEn: 'Immerse in studio-grade audio with active hybrid noise cancellation, 40-hour ultra battery life, and plush memory foam earcups.',
      descriptionBn: 'হাইব্রিড নয়েজ ক্যানসেলেশন ও ৪০ ঘণ্টার দীর্ঘস্থায়ী ব্যাটারি সমৃদ্ধ প্রিমিয়াম ওয়্যারলেস হেডফোন। স্পষ্ট সাউন্ড ও অসাধারণ বেস অভিজ্ঞতা।',
      basePriceUSD: 149.99,
      comparePriceUSD: 199.99,
      sku: 'ERO-TECH-001',
      brand: 'AuraSound',
      isFeatured: true,
      categoryId: catElectronics.id,
      ratingAverage: 4.8,
      ratingCount: 124,
      images: [
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=80',
      ],
      variants: [
        { sku: 'ERO-TECH-001-BLK', nameEn: 'Midnight Black', nameBn: 'মিডনাইট ব্ল্যাক', priceUSD: 149.99, stock: 45, attrs: JSON.stringify({ color: 'Black' }) },
        { sku: 'ERO-TECH-001-SLV', nameEn: 'Silver Platinum', nameBn: 'সিলভার প্ল্যাটিনাম', priceUSD: 154.99, stock: 28, attrs: JSON.stringify({ color: 'Silver' }) },
      ],
      customFields: [
        { key: 'warranty', labelEn: 'Warranty', labelBn: 'ওয়ারেন্টি', valEn: '2 Years Official', valBn: '২ বছরের অফিসিয়াল ওয়ারেন্টি' },
        { key: 'battery', labelEn: 'Battery Life', labelBn: 'ব্যাটারি ব্যাকআপ', valEn: '40 Hours', valBn: '৪০ ঘণ্টা' },
      ],
    },
    {
      titleEn: 'Classic Oxford Pure Egyptian Cotton Shirt',
      titleBn: 'ক্লাসিক অক্সফোর্ড পিওর কটন ফর্মাল শার্ট',
      slug: 'classic-oxford-cotton-shirt',
      descriptionEn: 'Crafted from 100% long-staple Egyptian cotton for unparalleled breathability, comfort, and a crisp tailored fit for business and leisure.',
      descriptionBn: '১০০% প্রিমিয়াম সুতি কাপড়ে তৈরি আরামদায়ক ও নিখুঁত ফিটিংযুক্ত ক্লাসিক ফর্মাল শার্ট। অফিস ও যেকোনো অনুষ্ঠানের জন্য আদর্শ।',
      basePriceUSD: 45.00,
      comparePriceUSD: 60.00,
      sku: 'ERO-FASH-002',
      brand: 'Erosae Tailored',
      isFeatured: true,
      categoryId: catFashion.id,
      ratingAverage: 4.9,
      ratingCount: 89,
      images: [
        'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80',
      ],
      variants: [
        { sku: 'ERO-FASH-002-WHT-M', nameEn: 'White / M', nameBn: 'সাদা / এম', priceUSD: 45.00, stock: 30, attrs: JSON.stringify({ color: 'White', size: 'M' }) },
        { sku: 'ERO-FASH-002-WHT-L', nameEn: 'White / L', nameBn: 'সাদা / এল', priceUSD: 45.00, stock: 40, attrs: JSON.stringify({ color: 'White', size: 'L' }) },
        { sku: 'ERO-FASH-002-BLU-M', nameEn: 'Sky Blue / M', nameBn: 'আকাশি / এম', priceUSD: 45.00, stock: 25, attrs: JSON.stringify({ color: 'Sky Blue', size: 'M' }) },
      ],
      customFields: [
        { key: 'material', labelEn: 'Material', labelBn: 'ফেব্রিক উপাদান', valEn: '100% Egyptian Cotton', valBn: '১০০% পিওর কটন' },
      ],
    },
    {
      titleEn: 'Nordic Minimalist Ceramic Aroma Diffuser & Lamp',
      titleBn: 'নর্ডিক সিরামিক অ্যারোমা ডিফিউজার ও অ্যাম্বিয়েন্ট ল্যাম্প',
      slug: 'nordic-ceramic-aroma-diffuser',
      descriptionEn: 'Ultrasonic essential oil diffuser with warm ambient light, automatic shutoff, and ultra-quiet operation for tranquil living.',
      descriptionBn: 'সিরামিক বডি ও নরম আলোর সমন্বয়ে তৈরি আল্ট্রাসনিক ডিফিউজার। ঘরকে সুবাসিত ও স্নিগ্ধ রাখতে সহায়তা করে।',
      basePriceUSD: 39.50,
      comparePriceUSD: 52.00,
      sku: 'ERO-HOME-003',
      brand: 'Nordic Zen',
      isFeatured: true,
      categoryId: catHome.id,
      ratingAverage: 4.7,
      ratingCount: 56,
      images: [
        'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800&auto=format&fit=crop&q=80',
      ],
      variants: [
        { sku: 'ERO-HOME-003-WHT', nameEn: 'Matte White', nameBn: 'ম্যাট হোয়াইট', priceUSD: 39.50, stock: 50, attrs: JSON.stringify({ color: 'White' }) },
      ],
      customFields: [
        { key: 'capacity', labelEn: 'Water Tank', labelBn: 'ধারণক্ষমতা', valEn: '300ml', valBn: '৩০০ মি.লি.' },
      ],
    },
    {
      titleEn: 'Botanical Radiance Vitamin C Serum 50ml',
      titleBn: 'বোটানিক্যাল রেডিয়েন্স ভিটামিন-সি ফেস সিরাম ৫০ মি.লি.',
      slug: 'botanical-radiance-vitamin-c-serum',
      descriptionEn: 'Potent 20% Vitamin C + Hyaluronic Acid formula that brightens complexion, fades dark spots, and protects against environmental stressors.',
      descriptionBn: 'ত্বকের উজ্জ্বলতা বৃদ্ধি ও দাগ দূর করতে কার্যকর ২০% ভিটামিন-সি ও হায়ালুরোনিক অ্যাসিড সমৃদ্ধ ন্যাচারাল স্কিন সিরাম।',
      basePriceUSD: 28.00,
      comparePriceUSD: 35.00,
      sku: 'ERO-BEAUTY-004',
      brand: 'Lumière Organics',
      isFeatured: true,
      categoryId: catBeauty.id,
      ratingAverage: 4.9,
      ratingCount: 210,
      images: [
        'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop&q=80',
      ],
      variants: [
        { sku: 'ERO-BEAUTY-004-50ML', nameEn: '50ml Glass Dropper', nameBn: '৫০ মি.লি. গ্লাস বোতল', priceUSD: 28.00, stock: 100, attrs: JSON.stringify({ size: '50ml' }) },
      ],
      customFields: [
        { key: 'volume', labelEn: 'Volume', labelBn: 'পরিমাণ', valEn: '50ml', valBn: '৫০ মি.লি.' },
      ],
    },
  ];

  for (const p of products) {
    const createdProduct = await prisma.product.upsert({
      where: { slug: p.slug },
      update: {
        titleEn: p.titleEn,
        titleBn: p.titleBn,
        descriptionEn: p.descriptionEn,
        descriptionBn: p.descriptionBn,
        basePriceUSD: p.basePriceUSD,
        comparePriceUSD: p.comparePriceUSD,
        sku: p.sku,
        brand: p.brand,
        isFeatured: p.isFeatured,
        categoryId: p.categoryId,
        ratingAverage: p.ratingAverage,
        ratingCount: p.ratingCount,
      },
      create: {
        titleEn: p.titleEn,
        titleBn: p.titleBn,
        slug: p.slug,
        descriptionEn: p.descriptionEn,
        descriptionBn: p.descriptionBn,
        basePriceUSD: p.basePriceUSD,
        comparePriceUSD: p.comparePriceUSD,
        sku: p.sku,
        brand: p.brand,
        isFeatured: p.isFeatured,
        categoryId: p.categoryId,
        ratingAverage: p.ratingAverage,
        ratingCount: p.ratingCount,
      },
    });

    // Images
    for (let i = 0; i < p.images.length; i++) {
      await prisma.productImage.create({
        data: {
          productId: createdProduct.id,
          url: p.images[i],
          altEn: p.titleEn,
          altBn: p.titleBn,
          isPrimary: i === 0,
          sortOrder: i,
        },
      });
    }

    // Variants
    for (const v of p.variants) {
      await prisma.productVariant.upsert({
        where: { sku: v.sku },
        update: {
          nameEn: v.nameEn,
          nameBn: v.nameBn,
          priceUSD: v.priceUSD,
          stockQuantity: v.stock,
          attributes: v.attrs,
        },
        create: {
          productId: createdProduct.id,
          sku: v.sku,
          nameEn: v.nameEn,
          nameBn: v.nameBn,
          priceUSD: v.priceUSD,
          stockQuantity: v.stock,
          attributes: v.attrs,
        },
      });
    }

    // Custom Fields
    for (const cf of p.customFields) {
      await prisma.productCustomField.create({
        data: {
          productId: createdProduct.id,
          fieldKey: cf.key,
          labelEn: cf.labelEn,
          labelBn: cf.labelBn,
          valueEn: cf.valEn,
          valueBn: cf.valBn,
        },
      });
    }
  }
  console.log('Products, images, variants, and custom fields seeded.');

  // 6. Payment Gateway Configurations
  const gateways = [
    {
      code: 'COD',
      name: 'Cash on Delivery (COD)',
      isEnabled: true,
      isLiveMode: true,
      supportedCurrencies: JSON.stringify(['BDT', 'USD', 'INR', 'AED', 'SAR', 'QAR', 'OMR', 'KWD', 'BHD', 'PKR']),
      credentialsEnc: '{}',
      sortOrder: 1,
    },
    {
      code: 'STRIPE',
      name: 'Credit / Debit Card (Stripe)',
      isEnabled: true,
      isLiveMode: false,
      supportedCurrencies: JSON.stringify(['USD', 'AED', 'SAR', 'QAR', 'EUR', 'GBP']),
      credentialsEnc: '{"publishableKey":"pk_test_demo","secretKey":"sk_test_demo"}',
      sortOrder: 2,
    },
    {
      code: 'BKASH',
      name: 'bKash / Mobile Financial Services',
      isEnabled: true,
      isLiveMode: false,
      supportedCurrencies: JSON.stringify(['BDT']),
      credentialsEnc: '{"appKey":"demo_key","appSecret":"demo_secret"}',
      sortOrder: 3,
    },
    {
      code: 'PAYPAL',
      name: 'PayPal Global',
      isEnabled: true,
      isLiveMode: false,
      supportedCurrencies: JSON.stringify(['USD', 'EUR', 'GBP', 'AUD', 'CAD']),
      credentialsEnc: '{"clientId":"paypal_client_demo"}',
      sortOrder: 4,
    },
  ];

  for (const gw of gateways) {
    await prisma.paymentGatewayConfig.upsert({
      where: { code: gw.code },
      update: gw,
      create: gw,
    });
  }
  console.log('Payment gateways seeded.');

  // 7. Shipping Rules
  const shippingRules = [
    { nameEn: 'Bangladesh Standard Delivery', nameBn: 'বাংলাদেশ স্ট্যান্ডার্ড ডেলিভারি', countryCode: 'BD', rateUSD: 1.0, freeAboveUSD: 30.0, estimatedDays: '2-4 Days' },
    { nameEn: 'UAE Express Delivery', nameBn: 'সংযুক্ত আরব আমিরাত এক্সপ্রেস ডেলিভারি', countryCode: 'AE', rateUSD: 5.0, freeAboveUSD: 80.0, estimatedDays: '1-3 Days' },
    { nameEn: 'Saudi Arabia Standard', nameBn: 'সৌদি আরব স্ট্যান্ডার্ড ডেলিভারি', countryCode: 'SA', rateUSD: 6.0, freeAboveUSD: 90.0, estimatedDays: '3-5 Days' },
    { nameEn: 'International Standard Shipping', nameBn: 'আন্তর্জাতিক সাধারণ শিপিং', countryCode: 'ALL', rateUSD: 15.0, freeAboveUSD: 150.0, estimatedDays: '7-14 Days' },
  ];

  for (const rule of shippingRules) {
    await prisma.shippingRule.create({ data: rule });
  }
  console.log('Shipping rules seeded.');

  console.log('Database seeding finished successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
