'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { SUPPORTED_CURRENCIES, CurrencyConfig, formatCurrency, convertFromUSD } from '@/lib/currency';
import { getDictionary, Locale } from '@/lib/i18n';

export interface CartItem {
  id: string;
  productId: string;
  variantId?: string;
  titleEn: string;
  titleBn: string;
  image: string;
  priceUSD: number;
  sku: string;
  quantity: number;
  variantNameEn?: string;
  variantNameBn?: string;
}

interface StoreContextType {
  locale: Locale;
  setLocale: (loc: Locale) => void;
  currency: string;
  setCurrency: (curr: string) => void;
  t: (key: string) => string;
  dict: any;
  cart: CartItem[];
  addToCart: (item: Omit<CartItem, 'quantity'>, qty?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, qty: number) => void;
  clearCart: () => void;
  cartSubtotalUSD: number;
  cartCount: number;
  formatPrice: (amountUSD: number) => string;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({
  children,
  initialLocale = 'en',
}: {
  children: React.ReactNode;
  initialLocale?: Locale;
}) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale);
  const [currency, setCurrencyState] = useState<string>('USD');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  // Initialize from localStorage on mount
  useEffect(() => {
    setIsMounted(true);
    const savedLocale = localStorage.getItem('erosae_locale') as Locale;
    if (savedLocale && (savedLocale === 'en' || savedLocale === 'bn')) {
      setLocaleState(savedLocale);
    }
    const savedCurrency = localStorage.getItem('erosae_currency');
    if (savedCurrency && SUPPORTED_CURRENCIES[savedCurrency]) {
      setCurrencyState(savedCurrency);
    }
    const savedCart = localStorage.getItem('erosae_cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error('Failed to parse saved cart');
      }
    }
  }, []);

  // Sync cart to localStorage
  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('erosae_cart', JSON.stringify(cart));
    }
  }, [cart, isMounted]);

  const setLocale = (newLoc: Locale) => {
    setLocaleState(newLoc);
    localStorage.setItem('erosae_locale', newLoc);
    document.cookie = `erosae_locale=${newLoc}; path=/; max-age=31536000`;
  };

  const setCurrency = (newCurr: string) => {
    setCurrencyState(newCurr);
    localStorage.setItem('erosae_currency', newCurr);
  };

  const dict = getDictionary(locale);

  const t = (path: string): string => {
    const keys = path.split('.');
    let current: any = dict;
    for (const k of keys) {
      if (current && typeof current === 'object' && k in current) {
        current = current[k];
      } else {
        return path;
      }
    }
    return typeof current === 'string' ? current : path;
  };

  const addToCart = (item: Omit<CartItem, 'quantity'>, qty = 1) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (i) => i.productId === item.productId && i.variantId === item.variantId
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += qty;
        return updated;
      }
      return [...prev, { ...item, id: `${item.productId}-${item.variantId || 'base'}-${Date.now()}`, quantity: qty }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((i) => i.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, qty: number) => {
    if (qty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((i) => (i.id === cartItemId ? { ...i, quantity: qty } : i))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartSubtotalUSD = cart.reduce((acc, i) => acc + i.priceUSD * i.quantity, 0);
  const cartCount = cart.reduce((acc, i) => acc + i.quantity, 0);

  const formatPrice = (amountUSD: number) => {
    return formatCurrency(amountUSD, currency, locale);
  };

  return (
    <StoreContext.Provider
      value={{
        locale,
        setLocale,
        currency,
        setCurrency,
        t,
        dict,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartSubtotalUSD,
        cartCount,
        formatPrice,
        isCartOpen,
        setIsCartOpen,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
