'use client';

import React, { useState } from 'react';
import { Languages, Save, CheckCircle, Sparkles } from 'lucide-react';

export default function AdminTranslationsPage() {
  const [translations, setTranslations] = useState({
    heroTitleEn: 'Discover Quality Across Every Category',
    heroTitleBn: 'সেরা মানের পণ্য কিনুন একই ঠিকানায়',
    heroSubtitleEn: 'Shop electronics, fashion, home essentials, beauty, and more with fast international delivery.',
    heroSubtitleBn: 'ইলেকট্রনিক্স, ফ্যাশন, গৃহসজ্জা, বিউটি ও নিত্যপ্রয়োজনীয় সব পণ্য পাচ্ছেন দ্রুত ডেলিভারি সুবিধায়।',
    bannerOfferEn: '✨ Erosae Grand Opening: Get 10% OFF your first order! Code: EROSAE10',
    bannerOfferBn: '✨ Erosae গ্র্যান্ড ওপেনিং অফার: প্রথম অর্ডারে ১০% ছাড় পান! কোড: EROSAE10',
    codLabelEn: 'Cash on Delivery (COD)',
    codLabelBn: 'ক্যাশ অন ডেলিভারি (COD)',
    deliveryTitleEn: 'Fast Regional Delivery',
    deliveryTitleBn: 'দ্রুত ডেলিভারি সুবিধা',
  });

  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-6">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center space-x-2">
            <Languages className="w-6 h-6 text-brand-500" />
            <span>Storefront Content & Natural Bengali Translations</span>
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Maintain authentic, natural Bengali phrasing across storefront banners, badges, and marketing copy.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-brand-600/20 transition"
        >
          <Save className="w-4 h-4" />
          <span>Save Translation Changes</span>
        </button>
      </div>

      {saved && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 rounded-2xl text-xs font-bold flex items-center space-x-2">
          <CheckCircle className="w-4 h-4" />
          <span>Translations and storefront copy updated live!</span>
        </div>
      )}

      {/* Translations Form */}
      <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div className="space-y-4">
            <h3 className="font-bold text-white uppercase tracking-wider text-[11px] border-b border-gray-800 pb-2">
              English Source
            </h3>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Hero Heading</label>
              <input
                type="text"
                value={translations.heroTitleEn}
                onChange={(e) => setTranslations({ ...translations, heroTitleEn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white"
              />
            </div>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Hero Subtitle</label>
              <textarea
                rows={2}
                value={translations.heroSubtitleEn}
                onChange={(e) => setTranslations({ ...translations, heroSubtitleEn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white"
              />
            </div>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Top Announcement Banner</label>
              <input
                type="text"
                value={translations.bannerOfferEn}
                onChange={(e) => setTranslations({ ...translations, bannerOfferEn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white"
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-brand-400 uppercase tracking-wider text-[11px] border-b border-gray-800 pb-2 flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5 text-gold-500" />
              <span>Natural Bengali Translation</span>
            </h3>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Hero Heading (বাংলা)</label>
              <input
                type="text"
                value={translations.heroTitleBn}
                onChange={(e) => setTranslations({ ...translations, heroTitleBn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white font-bengali"
              />
            </div>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Hero Subtitle (বাংলা)</label>
              <textarea
                rows={2}
                value={translations.heroSubtitleBn}
                onChange={(e) => setTranslations({ ...translations, heroSubtitleBn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white font-bengali"
              />
            </div>

            <div>
              <label className="block text-gray-400 mb-1 font-semibold">Top Announcement Banner (বাংলা)</label>
              <input
                type="text"
                value={translations.bannerOfferBn}
                onChange={(e) => setTranslations({ ...translations, bannerOfferBn: e.target.value })}
                className="w-full px-3.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white font-bengali"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
