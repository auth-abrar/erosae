'use client';

import React, { useState } from 'react';
import { DollarSign, Save, CheckCircle, RefreshCw } from 'lucide-react';
import { SUPPORTED_CURRENCIES } from '@/lib/currency';

export default function AdminCurrenciesPage() {
  const [currencies, setCurrencies] = useState(Object.values(SUPPORTED_CURRENCIES));
  const [saved, setSaved] = useState(false);

  const handleRateChange = (code: string, newRate: number) => {
    setCurrencies((prev) =>
      prev.map((c) => (c.code === code ? { ...c, exchangeRateToUSD: newRate } : c))
    );
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-6">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center space-x-2">
            <DollarSign className="w-6 h-6 text-brand-500" />
            <span>Multi-Currency & FX Engine</span>
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Manage exchange rates and decimal precision (3 decimals for KWD, OMR, BHD; 2 for USD, BDT, INR, etc.)
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-brand-600/20 transition"
        >
          <Save className="w-4 h-4" />
          <span>Save Exchange Rates</span>
        </button>
      </div>

      {saved && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 rounded-2xl text-xs font-bold flex items-center space-x-2">
          <CheckCircle className="w-4 h-4" />
          <span>Exchange rates updated successfully sitewide!</span>
        </div>
      )}

      {/* Currencies Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-3xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-gray-950/70 border-b border-gray-800 text-gray-400 uppercase text-[10px] font-bold">
            <tr>
              <th className="py-3 px-4">Currency Code</th>
              <th className="py-3 px-4">Name (English / Bengali)</th>
              <th className="py-3 px-4">Symbol</th>
              <th className="py-3 px-4">Decimals</th>
              <th className="py-3 px-4">Exchange Rate (Units per 1 USD)</th>
              <th className="py-3 px-4">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800 text-gray-300">
            {currencies.map((c) => (
              <tr key={c.code} className="hover:bg-gray-800/40 transition">
                <td className="py-3.5 px-4 font-mono font-bold text-white">
                  {c.code} {c.isDefault && <span className="text-[10px] text-brand-400 bg-brand-950 px-1.5 py-0.5 rounded ml-1">BASE</span>}
                </td>
                <td className="py-3.5 px-4">
                  <p className="font-semibold text-gray-200">{c.nameEn}</p>
                  <p className="text-[11px] text-gray-400 font-bengali">{c.nameBn}</p>
                </td>
                <td className="py-3.5 px-4 font-bold text-base text-gold-500">{c.symbol}</td>
                <td className="py-3.5 px-4">
                  <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${c.decimalPlaces === 3 ? 'bg-purple-950 text-purple-300 border border-purple-800' : 'bg-gray-800 text-gray-300'}`}>
                    {c.decimalPlaces} Decimals
                  </span>
                </td>
                <td className="py-3.5 px-4">
                  <input
                    type="number"
                    step="0.001"
                    disabled={c.isDefault}
                    value={c.exchangeRateToUSD}
                    onChange={(e) => handleRateChange(c.code, parseFloat(e.target.value) || 1)}
                    className="w-32 px-3 py-1.5 bg-gray-950 border border-gray-800 rounded-xl text-white font-mono font-bold text-xs focus:outline-none focus:ring-1 focus:ring-brand-500 disabled:opacity-50"
                  />
                </td>
                <td className="py-3.5 px-4">
                  <span className="text-emerald-400 font-bold text-[11px]">Active</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
