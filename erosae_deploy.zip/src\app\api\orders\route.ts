import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const orderId = searchParams.get('id');
    const orderNumber = searchParams.get('number');

    if (orderId || orderNumber) {
      const order = await db.order.findFirst({
        where: {
          OR: [
            orderId ? { id: orderId } : {},
            orderNumber ? { orderNumber } : {},
          ],
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
          payments: true,
        },
      });

      if (!order) {
        return NextResponse.json({ success: false, message: 'Order not found' }, { status: 404 });
      }

      return NextResponse.json({ success: true, order });
    }

    // List recent orders
    const orders = await db.order.findMany({
      include: {
        items: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({ success: true, orders });
  } catch (error: any) {
    console.error('Orders API error:', error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { orderId, status, paymentStatus, adminNotes } = body;

    const updated = await db.order.update({
      where: { id: orderId },
      data: {
        status: status || undefined,
        paymentStatus: paymentStatus || undefined,
        adminNotes: adminNotes || undefined,
      },
    });

    return NextResponse.json({ success: true, order: updated });
  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
